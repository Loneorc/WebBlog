package com.example.project.webblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebblogApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebblogApplication.class, args);
	}

}
